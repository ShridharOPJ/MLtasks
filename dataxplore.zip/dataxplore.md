```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder

# Set a style for the plots for better aesthetics
sns.set_style("whitegrid")
plt.style.use('seaborn-v0_8-whitegrid')

# NOTE: The file path is local to your computer.
# You will need to replace this with the actual path to your Excel file.
excel_file_path = r"C:\Users\Muhammad.shaamel\Documents\E-Commerce Dataset.xlsx"

# --- Part 1a: Load and Inspect ---
# =================================

try:
    # Read Sheet1 (Data Dictionary) and Sheet2 (E-Commerce data)
    # The data dictionary is useful for understanding column meanings, but we'll
    # focus on the main data for the analysis.
    print("Loading data from Excel file...")
    data_dict = pd.read_excel(excel_file_path, sheet_name="Sheet1")
    df = pd.read_excel(excel_file_path, sheet_name="Sheet2")
    
    # Correctly identify and set 'CustomerID' as a regular column if it's not.
    # The user's provided output shows it as a regular column, so we'll ensure that.
    if 'CustomerID' not in df.columns:
        df.reset_index(inplace=True)
        df.rename(columns={'index': 'CustomerID'}, inplace=True)
        
    print("Successfully loaded both sheets from the Excel file.")

    # Display initial inspection details
    print("\n--- Initial Data Inspection ---")
    print("\nDataFrame Shape (rows, columns):", df.shape)
    print("\nDataFrame Info:")
    df.info()
    
    print("\nMissing values per column:")
    print(df.isnull().sum())
    
    print("\nDescriptive Statistics for Numerical Features:")
    print(df.describe())

except FileNotFoundError:
    print(f"Error: The file was not found at the specified path: {excel_file_path}")
    print("Please check the file path and make sure the file exists.")
except Exception as e:
    print(f"An error occurred: {e}")

# --- Part 1b: Exploratory Data Analysis (EDA) ---
# ===============================================

# We will create at least three visualizations to uncover insights.
# We'll need to handle missing values for the visualizations.
# For simplicity, we will drop rows with missing values for now.
# A more robust approach might be imputation, but this is a good start for EDA.
df_eda = df.dropna().copy()
print("\n--- Performing Exploratory Data Analysis (EDA) ---")
print(f"Using a cleaned DataFrame with {df_eda.shape[0]} rows for EDA.")

# Visualization 1: Distribution of `CashbackAmount` by `Churn` status
# This visualization helps us see if the amount of cashback influences churn.
plt.figure(figsize=(10, 6))
sns.histplot(data=df_eda, x='CashbackAmount', hue='Churn', kde=True, bins=30)
plt.title('Distribution of Cashback Amount by Churn Status')
plt.xlabel('Cashback Amount')
plt.ylabel('Count')
plt.show()

print("\nVisualization 1 Insight: The distributions for Churn and Non-Churn customers are quite similar, suggesting that cashback amount may not be a strong predictor of churn.")

# Visualization 2: Count of customers by `CityTier` and `Churn`
# This bar chart shows if churn is more prevalent in certain city tiers.
plt.figure(figsize=(8, 6))
sns.countplot(data=df_eda, x='CityTier', hue='Churn')
plt.title('Customer Churn by City Tier')
plt.xlabel('City Tier')
plt.ylabel('Number of Customers')
plt.show()

print("Visualization 2 Insight: City Tier 1 has the most customers overall, and the proportion of churned customers appears to be relatively consistent across all three tiers.")

# Visualization 3: Box plot of `HourSpendOnApp` by `Churn`
# This box plot reveals if the amount of time spent on the app differs between churned and non-churned customers.
plt.figure(figsize=(8, 6))
sns.boxplot(data=df_eda, x='Churn', y='HourSpendOnApp')
plt.title('Hours Spent on App by Churn Status')
plt.xlabel('Churn (0 = No, 1 = Yes)')
plt.ylabel('Hours Spent on App')
plt.show()

print("Visualization 3 Insight: The median hours spent on the app seems to be slightly lower for customers who churn, though the difference is not drastic. There are also a few outliers.")

# --- Part 1c: Data Preprocessing ---
# ==================================

print("\n--- Starting Data Preprocessing ---")

# For preprocessing, we'll work with the original DataFrame and handle missing values.
# Dropping rows with any missing values is a straightforward approach for this task.
df_processed = df.dropna().copy()
print(f"Preprocessing DataFrame with {df_processed.shape[0]} rows after dropping missing values.")

# Encoding categorical variables
# We will use one-hot encoding for categorical features to prevent the model from
# assuming an ordinal relationship between different categories.
categorical_cols = df_processed.select_dtypes(include=['object']).columns
print("\nCategorical columns to encode:", list(categorical_cols))

df_processed = pd.get_dummies(df_processed, columns=categorical_cols, drop_first=True)
print("\nDataFrame shape after one-hot encoding:", df_processed.shape)

# Splitting the data into features (X) and target (y)
# The target variable is 'Churn'. We'll separate it from the features.
X = df_processed.drop('Churn', axis=1)
y = df_processed['Churn']
print(f"\nFeatures (X) shape: {X.shape}, Target (y) shape: {y.shape}")

# Splitting data into training and testing sets (80% train, 20% test)
# This is a crucial step to evaluate our model's performance on unseen data.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"Training set shape: X_train={X_train.shape}, y_train={y_train.shape}")
print(f"Testing set shape: X_test={X_test.shape}, y_test={y_test.shape}")

# Applying feature scaling
# We will use StandardScaler to standardize numerical features. This is important
# for many machine learning models that are sensitive to the scale of the input features,
# such as models that use gradient descent (e.g., Logistic Regression, SVMs, Neural Networks).
# We fit the scaler on the training data ONLY to prevent data leakage from the test set.
scaler = StandardScaler()

# Identify numerical columns for scaling
numerical_cols = X_train.select_dtypes(include=np.number).columns
X_train[numerical_cols] = scaler.fit_transform(X_train[numerical_cols])
X_test[numerical_cols] = scaler.transform(X_test[numerical_cols])

print("\nFeature scaling applied to numerical columns.")
print("Training data after scaling (first 5 rows):")
print(X_train.head())

print("\n--- Preprocessing Justification ---")
print("1. **Categorical Encoding**: One-hot encoding was chosen to convert non-numerical data into a format that machine learning models can process. It prevents the model from assuming an artificial order or rank between categories, which would be incorrect for variables like 'PreferredLoginDevice' or 'MaritalStatus'.")
print("2. **Data Splitting**: The data was split into training and testing sets to ensure that the model is evaluated on data it has not seen before. This provides a more realistic assessment of the model's generalization performance and helps in detecting overfitting.")
print("3. **Feature Scaling**: StandardScaler was applied to normalize the numerical features. This is a crucial step for algorithms that are sensitive to the magnitude of the features. It ensures that all features contribute equally to the distance calculation, preventing features with large values from dominating the learning process.")

```

    Loading data from Excel file...
    Successfully loaded both sheets from the Excel file.
    
    --- Initial Data Inspection ---
    
    DataFrame Shape (rows, columns): (5630, 20)
    
    DataFrame Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5630 entries, 0 to 5629
    Data columns (total 20 columns):
     #   Column                       Non-Null Count  Dtype  
    ---  ------                       --------------  -----  
     0   CustomerID                   5630 non-null   int64  
     1   Churn                        5630 non-null   int64  
     2   Tenure                       5366 non-null   float64
     3   PreferredLoginDevice         5630 non-null   object 
     4   CityTier                     5630 non-null   int64  
     5   WarehouseToHome              5379 non-null   float64
     6   PreferredPaymentMode         5630 non-null   object 
     7   Gender                       5630 non-null   object 
     8   HourSpendOnApp               5375 non-null   float64
     9   NumberOfDeviceRegistered     5630 non-null   int64  
     10  PreferedOrderCat             5630 non-null   object 
     11  SatisfactionScore            5630 non-null   int64  
     12  MaritalStatus                5630 non-null   object 
     13  NumberOfAddress              5630 non-null   int64  
     14  Complain                     5630 non-null   int64  
     15  OrderAmountHikeFromlastYear  5365 non-null   float64
     16  CouponUsed                   5374 non-null   float64
     17  OrderCount                   5372 non-null   float64
     18  DaySinceLastOrder            5323 non-null   float64
     19  CashbackAmount               5630 non-null   float64
    dtypes: float64(8), int64(7), object(5)
    memory usage: 879.8+ KB
    
    Missing values per column:
    CustomerID                       0
    Churn                            0
    Tenure                         264
    PreferredLoginDevice             0
    CityTier                         0
    WarehouseToHome                251
    PreferredPaymentMode             0
    Gender                           0
    HourSpendOnApp                 255
    NumberOfDeviceRegistered         0
    PreferedOrderCat                 0
    SatisfactionScore                0
    MaritalStatus                    0
    NumberOfAddress                  0
    Complain                         0
    OrderAmountHikeFromlastYear    265
    CouponUsed                     256
    OrderCount                     258
    DaySinceLastOrder              307
    CashbackAmount                   0
    dtype: int64
    
    Descriptive Statistics for Numerical Features:
             CustomerID        Churn       Tenure     CityTier  WarehouseToHome  \
    count   5630.000000  5630.000000  5366.000000  5630.000000      5379.000000   
    mean   52815.500000     0.168384    10.189899     1.654707        15.639896   
    std     1625.385339     0.374240     8.557241     0.915389         8.531475   
    min    50001.000000     0.000000     0.000000     1.000000         5.000000   
    25%    51408.250000     0.000000     2.000000     1.000000         9.000000   
    50%    52815.500000     0.000000     9.000000     1.000000        14.000000   
    75%    54222.750000     0.000000    16.000000     3.000000        20.000000   
    max    55630.000000     1.000000    61.000000     3.000000       127.000000   
    
           HourSpendOnApp  NumberOfDeviceRegistered  SatisfactionScore  \
    count     5375.000000               5630.000000        5630.000000   
    mean         2.931535                  3.688988           3.066785   
    std          0.721926                  1.023999           1.380194   
    min          0.000000                  1.000000           1.000000   
    25%          2.000000                  3.000000           2.000000   
    50%          3.000000                  4.000000           3.000000   
    75%          3.000000                  4.000000           4.000000   
    max          5.000000                  6.000000           5.000000   
    
           NumberOfAddress     Complain  OrderAmountHikeFromlastYear   CouponUsed  \
    count      5630.000000  5630.000000                  5365.000000  5374.000000   
    mean          4.214032     0.284902                    15.707922     1.751023   
    std           2.583586     0.451408                     3.675485     1.894621   
    min           1.000000     0.000000                    11.000000     0.000000   
    25%           2.000000     0.000000                    13.000000     1.000000   
    50%           3.000000     0.000000                    15.000000     1.000000   
    75%           6.000000     1.000000                    18.000000     2.000000   
    max          22.000000     1.000000                    26.000000    16.000000   
    
            OrderCount  DaySinceLastOrder  CashbackAmount  
    count  5372.000000        5323.000000     5630.000000  
    mean      3.008004           4.543491      177.223030  
    std       2.939680           3.654433       49.207036  
    min       1.000000           0.000000        0.000000  
    25%       1.000000           2.000000      145.770000  
    50%       2.000000           3.000000      163.280000  
    75%       3.000000           7.000000      196.392500  
    max      16.000000          46.000000      324.990000  
    
    --- Performing Exploratory Data Analysis (EDA) ---
    Using a cleaned DataFrame with 3774 rows for EDA.
    


    
![png](output_0_1.png)
    


    
    Visualization 1 Insight: The distributions for Churn and Non-Churn customers are quite similar, suggesting that cashback amount may not be a strong predictor of churn.
    


    
![png](output_0_3.png)
    


    Visualization 2 Insight: City Tier 1 has the most customers overall, and the proportion of churned customers appears to be relatively consistent across all three tiers.
    


    
![png](output_0_5.png)
    


    Visualization 3 Insight: The median hours spent on the app seems to be slightly lower for customers who churn, though the difference is not drastic. There are also a few outliers.
    
    --- Starting Data Preprocessing ---
    Preprocessing DataFrame with 3774 rows after dropping missing values.
    
    Categorical columns to encode: ['PreferredLoginDevice', 'PreferredPaymentMode', 'Gender', 'PreferedOrderCat', 'MaritalStatus']
    
    DataFrame shape after one-hot encoding: (3774, 31)
    
    Features (X) shape: (3774, 30), Target (y) shape: (3774,)
    Training set shape: X_train=(3019, 30), y_train=(3019,)
    Testing set shape: X_test=(755, 30), y_test=(755,)
    
    Feature scaling applied to numerical columns.
    Training data after scaling (first 5 rows):
          CustomerID    Tenure  CityTier  WarehouseToHome  HourSpendOnApp  \
    965    -1.296415 -0.869139 -0.749008        -0.211377       -1.380966   
    2090   -0.592132  2.494046 -0.749008         0.967537        0.015262   
    5167    1.334159 -0.998492 -0.749008         0.613863        0.015262   
    1321   -1.073548 -0.222373  1.391318         2.146451        0.015262   
    4555    0.951029  1.071160 -0.749008         1.439103        1.411490   
    
          NumberOfDeviceRegistered  SatisfactionScore  NumberOfAddress  Complain  \
    965                   1.197853           1.408105        -0.094772 -0.622421   
    2090                 -0.747450           0.688195        -0.094772  1.606629   
    5167                  0.225202          -1.471536        -0.869111  1.606629   
    1321                  0.225202          -0.031715        -0.869111 -0.622421   
    4555                  0.225202          -1.471536         1.841073 -0.622421   
    
          OrderAmountHikeFromlastYear  ...  PreferredPaymentMode_E wallet  \
    965                     -0.756333  ...                      -0.370270   
    2090                    -0.480863  ...                      -0.370270   
    5167                    -0.756333  ...                      -0.370270   
    1321                     1.447425  ...                       2.700733   
    4555                     1.447425  ...                      -0.370270   
    
          PreferredPaymentMode_UPI  Gender_Male  PreferedOrderCat_Grocery  \
    965                   3.575666    -1.238030                  -0.04073   
    2090                 -0.279668     0.807735                  -0.04073   
    5167                  3.575666    -1.238030                  -0.04073   
    1321                 -0.279668    -1.238030                  -0.04073   
    4555                 -0.279668     0.807735                  -0.04073   
    
          PreferedOrderCat_Laptop & Accessory  PreferedOrderCat_Mobile  \
    965                              0.965805                -0.186045   
    2090                             0.965805                -0.186045   
    5167                            -1.035406                -0.186045   
    1321                             0.965805                -0.186045   
    4555                            -1.035406                -0.186045   
    
          PreferedOrderCat_Mobile Phone  PreferedOrderCat_Others  \
    965                       -0.692750                -0.072993   
    2090                      -0.692750                -0.072993   
    5167                      -0.692750                -0.072993   
    1321                      -0.692750                -0.072993   
    4555                       1.443523                -0.072993   
    
          MaritalStatus_Married  MaritalStatus_Single  
    965                0.956875             -0.710095  
    2090               0.956875             -0.710095  
    5167              -1.045069              1.408262  
    1321               0.956875             -0.710095  
    4555               0.956875             -0.710095  
    
    [5 rows x 30 columns]
    
    --- Preprocessing Justification ---
    1. **Categorical Encoding**: One-hot encoding was chosen to convert non-numerical data into a format that machine learning models can process. It prevents the model from assuming an artificial order or rank between categories, which would be incorrect for variables like 'PreferredLoginDevice' or 'MaritalStatus'.
    2. **Data Splitting**: The data was split into training and testing sets to ensure that the model is evaluated on data it has not seen before. This provides a more realistic assessment of the model's generalization performance and helps in detecting overfitting.
    3. **Feature Scaling**: StandardScaler was applied to normalize the numerical features. This is a crucial step for algorithms that are sensitive to the magnitude of the features. It ensures that all features contribute equally to the distance calculation, preventing features with large values from dominating the learning process.
    


```python

```
